

let fetchOptions = {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify(data),
};

fetch(
  "https://crudcrud.com/api/7fba6b5c1a5049ca98b37bdcc0373e54/todo",
  fetchOptions
)
  .then((response) => response.json())
  .then((data) => console.log(data));